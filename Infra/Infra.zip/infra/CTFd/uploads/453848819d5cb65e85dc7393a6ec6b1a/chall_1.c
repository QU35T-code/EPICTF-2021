#include <stdio.h>
#include <stdlib.h>

void ignore_me_init_buffering();
void ignore_me_init_signal();

void vuln()
{
    char name[16];
    int is_admin = 0;

    printf("What is your name ?\n> ");
    scanf("%s", name);
    printf("Hello %s\n", name);
    if (is_admin != 0)
        system("/bin/bash");
    else
        printf("Sorry, you are not admin (is_admin = %x)\n", is_admin);
}

int main()
{
    ignore_me_init_buffering();
    ignore_me_init_signal();
    vuln();
    return 0;
}