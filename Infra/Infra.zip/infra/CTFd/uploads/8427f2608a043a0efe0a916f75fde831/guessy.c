#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void ignore_me_init_buffering();
void ignore_me_init_signal();

void shell(void)
{
    system("/bin/bash");
}

void vuln(void)
{
    int rand_number;
    int user_number;

    srand(time(0));
    rand_number = rand() % 10;
    printf("Can you guess my number?\n> ");
    scanf("%d", &user_number);
    if (rand_number == user_number) {
        rand_number = rand();
        printf("Well done, but can you guess my second number?\n> ");
        scanf("%d", &user_number);
        if (rand_number == user_number) {
            shell();
        } else {
            printf("Wrong answer, it was %d\n", rand_number);
        }
    } else {
        printf("Wrong answer, it was %d\n", rand_number);
    }
}

int main(void)
{
    ignore_me_init_buffering();
    ignore_me_init_signal();
    vuln();
    return 0;
}