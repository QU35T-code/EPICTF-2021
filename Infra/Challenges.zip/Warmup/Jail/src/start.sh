#!/bin/sh

cd /ctf
/usr/local/bin/python3 /ctf/jail.py
